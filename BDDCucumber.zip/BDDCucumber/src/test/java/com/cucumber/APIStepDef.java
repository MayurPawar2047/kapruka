package com.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.Assert;

public class APIStepDef {
    Response response;

    @Given("the user sets the baseURI for JSONPLACEHOLDER")
    public void theUserSetsTheBaseURIForJSONPLACEHOLDER() {

        RestAssured.baseURI="https://jsonplaceholder.typicode.com/";
    }

    @When("send the GET request to {string}")
    public void sendTheGETRequestTo(String endpoint) {
        response= RestAssured.given().when().get(endpoint);
    }

    @Then("check if the response status code is {int}")
    public void checkIfTheResponseStatusCodeIs(int exp_status_code) {

        int actual_status_code=response.getStatusCode();
        Assert.assertEquals(exp_status_code,actual_status_code);
        System.out.println("Actual Status Code"+actual_status_code+" "+"Expected Status Code"+exp_status_code);

    }

    @Then("check if the response should contain userID as {int}")
    public void checkIfTheResponseShouldContainUserIDAs(int exp_user_Id) {

        int actual_user_Id=response.jsonPath().getInt("userId");
        Assert.assertEquals(exp_user_Id,actual_user_Id);
        System.out.println("Actual Response Id:"+actual_user_Id+" "+"Expected Response Id:"+exp_user_Id);
    }
}
