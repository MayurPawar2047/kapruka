package com.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.junit.Assert;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class PetStorePostStepdefs {
    private String baseUrl;
    private Response response;
    
    private Map<String,Object> requestBody;
    
    @Given("I set the Pet Store user creation endpoint")
    public void iSetThePetStoreUserCreationEndpoint() {
        baseUrl="https://petstore.swagger.io/v2/user";
    }

    @When("I create a user with the following details")
    public void iCreateAUserWithTheFollowingDetails(io.cucumber.datatable.DataTable dataTable) {
        requestBody = new HashMap<>();
        Map<String, String> data = dataTable.asMap(String.class, String.class);

        requestBody.put("id", Integer.parseInt(data.get("id")));
        requestBody.put("username", data.get("username"));
        requestBody.put("firstName", data.get("firstName"));
        requestBody.put("lastName", data.get("lastName"));
        requestBody.put("email", data.get("email"));
        requestBody.put("password", data.get("password"));
        requestBody.put("phone", data.get("phone"));
        requestBody.put("userStatus", Integer.parseInt(data.get("userStatus")));

        response = given()
                .contentType("application/json")
                .body(requestBody)
                .when()
                .post(baseUrl);
    }

    @Then("I should receive status code {int}")
    public void iShouldReceiveStatusCode(int expectedStatusCode) {
        response.then().statusCode(expectedStatusCode);
        int actualStatusCode = response.getStatusCode();
        Assert.assertEquals(expectedStatusCode,actualStatusCode);
        System.out.println("ResponseBody:\n"+response.asPrettyString());
        System.out.println("Expected Status Code: " + expectedStatusCode);
        System.out.println("Actual Status Code: " + actualStatusCode);
    }
}
