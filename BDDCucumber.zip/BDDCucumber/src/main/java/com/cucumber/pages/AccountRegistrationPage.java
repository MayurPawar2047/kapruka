package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static com.cucumber.commonbase.Base.driver;

public class AccountRegistrationPage extends Base {


    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    // Locators
    private final By profile_icon = By.xpath("//a[@aria-label='Login to Your Account']//*[name()='svg']//*[name()='path']");
    private final By create_account_btn = By.xpath("//button[@class='btn btn-primary']");


    private final By newCustomersHeading = By.xpath("//h3[normalize-space()='New Customers']");
    private final By firstName = By.xpath("//input[@name='firstName']");
    private final By lastName = By.xpath("//input[@name='lastName']");
    private final By email = By.xpath("//input[@name='email']");
    private final By password = By.xpath("//input[@name='password']");
    private final By passwordReConfirm = By.xpath("//input[@name='passwordReConfirm']");
    private final By createAccountBtn = By.xpath("//button[normalize-space()='Create Account']");

    private final By errorMessage = By.xpath("//div[contains(@class, 'alert-danger')]");
    //b[contains(text(),"We're sorry, there is a slight problem (see below)")]
    private final By successMessage = By.xpath("//h3[normalize-space()='Congratulations! Your account has been created.']");

    // Method to get error message text
    public String getErrorMessage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage));
        return driver.findElement(errorMessage).getText();
    }

    // Method to check if error message is displayed
    public boolean isErrorMessageDisplayed() {
        return driver.findElement(errorMessage).isDisplayed();
    }

    // Method to get success message text
    public String getSuccessMessage() {
        return waitForVisibility(successMessage).getText();
    }

    // Method to check if success message is displayed
    public boolean isSuccessMessageDisplayed() {
        return driver.findElement(successMessage).isDisplayed();
    }

    // Method to get the heading text
    public String getNewCustomersHeading() {
        return driver.findElement(newCustomersHeading).getText();
    }

    // Optional: method to check if it's displayed
    public boolean isNewCustomersHeadingDisplayed() {
        return driver.findElement(newCustomersHeading).isDisplayed();
    }

    // Methods to interact with elements
    public void enterFirstName(String fName) {
        driver.findElement(firstName).clear();
        driver.findElement(firstName).sendKeys(fName);
    }

    public void enterLastName(String lName) {
        driver.findElement(lastName).clear();
        driver.findElement(lastName).sendKeys(lName);
    }

    public void enterEmail(String userEmail) {
        driver.findElement(email).clear();
        driver.findElement(email).sendKeys(userEmail);
    }

    public void enterPassword(String pwd) {
        driver.findElement(password).clear();
        driver.findElement(password).sendKeys(pwd);
    }

    public void reEnterPassword(String confirmPwd) {
        driver.findElement(passwordReConfirm).clear();
        driver.findElement(passwordReConfirm).sendKeys(confirmPwd);
    }

    public void clickCreateAccountButton() {
        driver.findElement(createAccountBtn).click();
    }

    public void clickProfileIcon() {
        driver.findElement(profile_icon).click();
    }

    public void clickAccountCreationBTN() {
        driver.findElement(create_account_btn).click();
    }

    // Combined registration method
//    public void registerAccount(String fName, String lName, String userEmail, String pwd, String confirmPwd) {
//        enterFirstName(fName);
//        enterLastName(lName);
//        enterEmail(userEmail);
//        enterPassword(pwd);
//        reEnterPassword(confirmPwd);
//        clickCreateAccountButton();
//    }



    }




