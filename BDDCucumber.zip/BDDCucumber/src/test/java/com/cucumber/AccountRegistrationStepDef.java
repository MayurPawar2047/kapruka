package com.cucumber;
import com.cucumber.commonbase.Base;
import com.cucumber.pages.AccountRegistrationPage;
import com.cucumber.pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class AccountRegistrationStepDef extends Base  {

    WebDriver driver;
    AccountRegistrationPage accountRegistrationPage;

    public AccountRegistrationStepDef(){
        driver= com.cucumber.Hooks.driver;
        accountRegistrationPage=new AccountRegistrationPage();
    }
    @Given("URL is launched")
    public void urlIsLaunched() {
        driver.get("https://www.kapruka.com/");
       }

    @When("I click on personal icon")
    public void i_click_on_personal_icon() {
        accountRegistrationPage.clickProfileIcon();
    }
    @When("I click on Create Account button")
    public void i_click_on_create_account_button() {
        accountRegistrationPage.clickCreateAccountButton();
    }
    @When("I enter first name as {string}")
    public void i_enter_first_name_as(String string) {
        accountRegistrationPage.enterFirstName(string);
    }
    @When("I enter last name as {string}")
    public void i_enter_last_name_as(String string) {
        accountRegistrationPage.enterLastName(string);
    }
    @When("I enter email as {string}")
    public void i_enter_email_as(String string) {
        accountRegistrationPage.enterEmail(string);
    }
    @When("I enter password as {string}")
    public void i_enter_password_as(String string) {
        accountRegistrationPage.enterPassword(string);
    }
    @When("I re-enter password as {string}")
    public void i_re_enter_password_as(String string) {
        accountRegistrationPage.reEnterPassword(string);
    }
    @Then("I should see the success message {string}")
    public void i_should_see_the_success_message(String string) {
        accountRegistrationPage.clickAccountCreationBTN();
    }


}
