package com.cucumber;

import com.cucumber.commonservices.ExcelHelper;
import com.cucumber.pages.LoginPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.poi.xssf.usermodel.XSSFSheet;

public class ExcelSteps {
    ExcelHelper excelHelper;
    LoginPage login=new LoginPage();

    ExcelSteps(){
        excelHelper = new ExcelHelper();

    }


    XSSFSheet sheet;
    String filePath = "src/test/resources/testdata/data.xlsx";  // adjust as needed


    @When("I login with the website with excel data")
    public void i_login_with_excel_data() {
        System.out.println("Login with data from Excel - logic to be implemented.");
        // You would extract username/password from the sheet here and call login logic
    }

    @Then("I should see dashboard now")
    public void i_should_see_dashboard_now() {

       // System.out.println("User should be on the dashboard - assertion to be implemented.");
    }

    @When("read from excel")
    public void read_from_excel() {
        XSSFSheet sheet = excelHelper.getExcelSheetTableData("C://Users//Mayur Pawar//Desktop//SM Express Project//TestData.xlsx", "TestData.xlsx", "Test");
        //actual=sheet.getRow(2).getCell(2).getStringCellValue();
         int rowCount = sheet.getPhysicalNumberOfRows();
        System.out.println(rowCount);
        String email;
        String password;
        for (int i = 1; i < rowCount; i++){
            email=sheet.getRow(i).getCell(1).getStringCellValue();

            login.enterEmail(email);
            //login.enterPassword(password);
        }


         //System.out.println("Reading data from Excel: Sheet '" + sheetName + "' loaded.");
    }

    @Then("data should display from excel")
    public void data_should_display_from_excel() {
        if (sheet == null) {
            System.out.println("Sheet is null. Please check file path or sheet name.");
            return;
        }

        int rowCount = sheet.getPhysicalNumberOfRows();
        for (int i = 0; i < rowCount; i++) {
            int colCount = sheet.getRow(i).getLastCellNum();
            for (int j = 0; j < colCount; j++) {
                String cellValue = sheet.getRow(i).getCell(j).toString();
                System.out.print(cellValue + " | ");
            }
            System.out.println();
        }
    }

    @When("write to excel")
    public void write_to_excel() {
        System.out.println("Logic for writing to Excel not implemented yet.");
        // Placeholder for write logic
    }

    @Then("data should display")
    public void data_should_display() {
        System.out.println("Display confirmation of written data - logic to be added.");
    }
}
