package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class HomePage extends Base {

    private final By whatAppbtn = By.xpath("//span[normalize-space()='Join Our Whatsapp Channel']");


    public void clickJoinsOption() {


        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement subscribeOption= driver.findElement(whatAppbtn);
        js.executeScript("arguments[0].scrollIntoView(true);", subscribeOption);

        //subscribeOption.click();

        //js.executeScript("arguments[0].click();", whatAppbtn);
    }

    public void clickWhatsAppOption(){
        driver.findElement(whatAppbtn).click();
    }

}
