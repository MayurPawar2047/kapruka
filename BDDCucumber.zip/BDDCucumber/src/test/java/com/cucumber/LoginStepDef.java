package com.cucumber;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.cucumber.commonbase.Base;
import com.cucumber.commonservices.ScreenshotServices;
import com.cucumber.commonvalidation.ComValidation;
import com.cucumber.pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;


public class LoginStepDef extends Base {
WebDriver driver;
    LoginPage loginPage;
    ScreenshotServices services;

   public LoginStepDef(){
        driver= com.cucumber.Hooks.driver;
        loginPage=new LoginPage();
       services=new ScreenshotServices();
    }

//    public void launchBrowser(){
//       driver.get("https://www.kapruka.com/");
//    }

    @When("I login with the website")
    public void iLoginWithTheWebsite() {
       loginPage.launchURL();
       loginPage.clickProfile_icon();

       loginPage.enterEmail(" mayurpawar2400@gmail.com");
        loginPage.enterPassword("Admin@123");
        loginPage.clickOnLogin();
    }

    @Then("I should see dashboard")
    public void iShouldSeeDashboard() {
       try{
           System.out.println("Dashboard");
           String actualTitle = loginPage.getAssertTitleOfWebsite();
           String expectedResult = "New Account Creation";
       }
       catch (Exception e)
       {
           ExtentCucumberAdapter.getCurrentStep().fail(e.getMessage());
           scenario.attach(services.getScreenshot(), ComValidation.IMAGEPNG, scenario.getName());
       }
    }

    @When("user enter valid credentials and click on login")
    public void userEnterValidCredentialsAndClickOnLogin() {
    }


    @When("user fetch the title")
    public void userFetchTheTitle() {
      loginPage.getTitleOfWebsite();
    }

    @Then("title should display")
    public void titleShouldDisplay() {
        try {
            String actualResult = loginPage.getAssertTitleOfWebsite();
            String exptedResult = "Kapruka.com | Sri Lanka Online Shopping Site | Send Gifts to Sri Lanka";
            Assert.assertEquals(exptedResult, actualResult);
        } catch (Exception e) {
            ExtentCucumberAdapter.getCurrentStep().fail(e.getMessage());

            scenario.attach(services.getScreenshot(), ComValidation.IMAGEPNG, scenario.getName());
        }
    }
}