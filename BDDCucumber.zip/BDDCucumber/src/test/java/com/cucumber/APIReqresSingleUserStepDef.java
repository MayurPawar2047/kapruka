package com.cucumber;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.Assert;

import static io.restassured.RestAssured.given;

public class APIReqresSingleUserStepDef {
    Response response;

    @Given("the user sets the baseURI for reqres")
    public void theUserSetsTheBaseURIForReqres() {
        RestAssured.baseURI="https://reqres.in";

        }



    @Then("check if the response should contain ID as {int}")
    public void checkIfTheResponseShouldContainIDAs(int exp_user_Id) {
        response = given().when().get("/api/users/2");
        int id=response.jsonPath().getInt("data.id");
        Assert.assertEquals(exp_user_Id,id);
        System.out.println("Actual Response Id:"+id+" "+"Expected Response Id:"+exp_user_Id);
    }

    @And("check if the response should contain email {string}")
    public void checkIfTheResponseShouldContainEmail(String exp_email) {

        response = given().when().get("/api/users/2");
        String email = response.jsonPath().getString("data.email");
        Assert.assertEquals(exp_email,email);
        System.out.println("Actual Response Id:"+email+" "+"Expected Response Id:"+exp_email);
    }

    // int id = response.jsonPath().getInt("data.id");
//String email = response.jsonPath().getString("data.email");

    //Response response = given().when().get("/users/2");
    //int id = response.jsonPath().getInt("data.id");
}
