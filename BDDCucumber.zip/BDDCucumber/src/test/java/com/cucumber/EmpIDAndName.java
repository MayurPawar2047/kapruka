package com.cucumber;

import java.util.HashMap;

public class EmpIDAndName {
    public static void main(String[] args) {
        HashMap<Integer,String> emp=new HashMap<>();
        emp.put(1,"Mayur");
        emp.put(2,"Nagrajan");
        emp.put(3,"Akshay");

        System.out.println(emp.get(2));
    }
}
