package com.cucumber.commonvalidation;

public class ComValidation {
    public static final String IMAGEPNG="image/png";
}
