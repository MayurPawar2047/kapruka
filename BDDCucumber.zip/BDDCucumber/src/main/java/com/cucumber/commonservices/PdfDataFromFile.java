package com.cucumber.commonservices;

public class PdfDataFromFile {

  //  Print obj=new Print();
  //           =obj.getPdfContent();
}
