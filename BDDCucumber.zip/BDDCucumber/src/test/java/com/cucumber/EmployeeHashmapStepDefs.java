package com.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.junit.Assert;


import java.util.HashMap;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

public class EmployeeHashmapStepDefs {
    Response response;

    @Given("I set the POST API endpoint")
    public void iSetThePOSTAPIEndpoint() {
        baseURI = "https://reqres.in/api/users";
    }

    @When("I send POST request with user details")
    public void iSendPOSTRequestWithUserDetails() {
        HashMap<String, String> emp = new HashMap<>();
        emp.put("name","morpheus");
        emp.put("job", "leader");
       // emp.put("id", 1);

        response = given()
                .header("Content-Type", "application/json")
                .header("x-api-key", "reqres-free-v1")
                .body(emp)
                .when()
                .post(baseURI);
    }


    @Then("I should receive a successful response with status code {int}")
    public void iShouldReceiveASuccessfulResponseWithStatusCode(int exp_status_code) {

        // Validate the status code
//        int actual_status_code = response.getStatusCode();
//        Assert.assertEquals("Status code mismatch", exp_status_code, actual_status_code);
//        System.out.println("Actual Status Code: " + actual_status_code + " | Expected Status Code: " + exp_status_code);

       
        // Get first post
//        int userId1 = response.jsonPath().getInt("userId");
//        int id1 = response.jsonPath().getInt("id");
       // String title1 = response.jsonPath().getString(".title");

        // Assert first post values
//        Assert.assertEquals(userId1, 1);
//        Assert.assertEquals(id1, 1);
       // Assert.assertEquals(title1, "sunt aut facere repellat provident occaecati excepturi optio reprehenderit");

        // Get second post
//        int userId2 = response.jsonPath().getInt("userId");
//        int id2 = response.jsonPath().getInt("id");
       // String title2 = response.jsonPath().getString("title");

        // Assert second post values
//        Assert.assertEquals(userId2, 1);
//        Assert.assertEquals(id2, 2);
       // Assert.assertEquals(title2, "qui est esse");


      String name = response.jsonPath().getString("name");
        String job = response.jsonPath().getString("job");
        Assert.assertEquals("morpheus", name);
     Assert.assertEquals("leader", job);
     System.out.println("name: "+name+" "+"job: "+job);

//        int actual_status_code = response.getStatusCode();
//        Assert.assertEquals(exp_status_code, actual_status_code);
//        System.out.println("Actual Status Code: " + actual_status_code + " " + "Expected Status Code: " + exp_status_code);
//        System.out.println("Time Taken: " + response.getTime() + " " + "Body: " + response.getBody().toString());      // ..............................
        // response.then().statusCode(201);

        // System.out.println("Actual Status Code"+actual_status_code+" "+"Expected Status Code"+exp_status_code);


    }

    @Then("I should see the response contains userId as {int}")
    public void iShouldSeeTheResponseContainsUserIdAs(int exp_user_Id) {
        int actual_user_Id=response.jsonPath().getInt("userId");
        Assert.assertEquals(exp_user_Id,actual_user_Id);
        System.out.println("Actual Response Id:"+actual_user_Id+" "+"Expected Response Id:"+exp_user_Id);
    }
}
