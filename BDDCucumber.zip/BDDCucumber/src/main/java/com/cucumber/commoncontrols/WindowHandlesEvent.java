package com.cucumber.commoncontrols;

import org.openqa.selenium.WebDriver;

public class WindowHandlesEvent {

    public void toChange(WebDriver driver)
    {
        String originalHandle=driver.getWindowHandle();

        for(String handle:driver.getWindowHandles())
    }
}
