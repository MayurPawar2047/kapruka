package com.cucumber;

import com.cucumber.commonbase.Base;
import com.cucumber.pages.LoginPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import static org.junit.Assert.assertEquals;

public class LoginWithScenarioOutline extends Base {
    WebDriver driver;
    LoginPage loginPage;

    public LoginWithScenarioOutline(){
        driver= com.cucumber.Hooks.driver;
        loginPage=new LoginPage();
    }


@When("User enters {string} and {string}")
public void user_enters_credentials(String email,String password)
{
   // loginPage.launchURL();
    loginPage.clickProfile_icon();
    loginPage.enterEmail(email);
    loginPage.enterPassword(password);
}

    @Then("click on login button")
    public void clickOnLoginButton() {

        loginPage.clickOnLogin();
    }

@Then("User should see {string}")
public void user_should_see_result(String expectedResult)
{
    String actualMessage="";

    if (expectedResult.equalsIgnoreCase("login is Successful")){
        actualMessage=driver.getTitle();
        assertEquals("Kapruka-Home",actualMessage);
    }
    else {
        actualMessage = loginPage.getErrorMessage();
        System.out.println("Actual Error Message: " + actualMessage);
        assertEquals(expectedResult, actualMessage);
    }
}



    @When("user enters  {string} and {string}")
    public void userEntersAnd(String email, String password) {
        loginPage.enterEmail(email);
        loginPage.enterPassword(password);
    }

    @Then("user should see {string}")
    public void userShouldSee(String arg0) {
    }
}
