package com.cucumber;

import com.cucumber.commonservices.ScreenshotServices;
import com.cucumber.pages.HomePage;
import com.cucumber.pages.LoginPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class HomePageScrolStepDef {

    WebDriver driver;
    HomePage homePage;
    ScreenshotServices services;

    public HomePageScrolStepDef(){
        driver= com.cucumber.Hooks.driver;
        homePage=new HomePage();
    }

    @Then("Join button should be visible")
    public void joinButtonShouldBeVisible() throws InterruptedException {
        Thread.sleep(3000);
        homePage.clickJoinsOption();
    }

    @When("user click on Join option")
    public void userClickOnJoinOption() throws InterruptedException {
        Thread.sleep(3000);
        homePage.clickWhatsAppOption();
    }
}
