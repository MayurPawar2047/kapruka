package com.cucumber;

import com.cucumber.commonbase.Base;
import com.cucumber.commonservices.ScreenshotServices;
import com.cucumber.pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import org.openqa.selenium.WebDriver;

public class LogoutsStep extends Base {

    LoginPage loginPage;
    WebDriver driver;
    ScreenshotServices services;

    public LogoutsStep(){
        driver= com.cucumber.Hooks.driver;
        loginPage=new LoginPage();
        services = new ScreenshotServices();
    }

    @Given("user is login into the application")
    public void userIsLoginIntoTheApplication() {
        loginPage.launchURL();
        loginPage.clickProfile_icon();

        loginPage.enterEmail("mayurpawar2400@gmail.com");
        loginPage.enterPassword("Admin@123");
        loginPage.clickOnLogin();
        
    }

    @When("user click on the logout button")
    public void userClickOnTheLogoutButton() {
        loginPage.clickonlogoutBtn();

    }

    @Then("user should be redirected to the login page")
    public void userShouldBeRedirectedToTheLoginPage() {
        String currentUrl = driver.getCurrentUrl();
        System.out.println(currentUrl);
        Assert.assertTrue("User is not redirected to login page", currentUrl.contains("accountLogin.jsp"));
    }
}
