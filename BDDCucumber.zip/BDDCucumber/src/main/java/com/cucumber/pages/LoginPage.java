package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;

public class LoginPage extends Base {

    private final By profile_icon = By.xpath("//a[@aria-label='Login to Your Account']//*[name()='svg']//*[name()='path']");


    //WebDropdown dropdown=new WebDropdown()
    private final By email = By.id("exampleInputEmail1");

    private final By login = By.xpath("//input[@name='Login']");

    private final By message = By.xpath("//font[@color='red']");

    private final By logoutBtn = By.xpath("//div[contains(text(),'Logout')]");

    public void enterEmail(String username)
    {
        driver.findElement(email).clear();
        driver.findElement(email).sendKeys(username);
        //driver.findElement(By.id("exampleInputEmail1")).sendTextToKeyBoardInput(driver,By.id("exampleInputEmail1")),"a","CONTROL");
    }

    public void clickYourAccount() throws InterruptedException {
//change this line to get error
        driver.findElement(By.xpath("//div[@class='orderStatusIcon']")).click();
    }

        public void enterPassword(String password)
        {
            driver.findElement(By.id("exampleInputPassword1")).clear();
            driver.findElement(By.id("exampleInputPassword1")).sendKeys(password);

        }

        public void getTitleOfWebsite()
        {
            String title= driver.getTitle();
            System.out.println(title);
        }

    public String getAssertTitleOfWebsite()
    {
       String title= driver.getTitle();
        return title;

    }
    public void clickProfile_icon(){
        driver.findElement(profile_icon).click();
    }

    public void clickOnLogin(){
        driver.findElement(login).click();
    }

    public String getErrorMessage() {
        return driver.findElement(message).getText();
    }

    public void launchURL(){
        driver.get("https://www.kapruka.com/");
    }

    public void clickonlogoutBtn()
    {
        driver.findElement(logoutBtn).click();
    }


        }